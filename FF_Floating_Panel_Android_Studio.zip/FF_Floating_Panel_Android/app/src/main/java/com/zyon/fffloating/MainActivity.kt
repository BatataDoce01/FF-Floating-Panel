package com.zyon.fffloating

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 28, 28, 28)
            setBackgroundColor(0xFF0B0D12.toInt())
        }
        val title = TextView(this).apply {
            text = "FF TACTICAL PANEL"
            textSize = 24f
            setTextColor(0xFFFF3947.toInt())
            gravity = Gravity.CENTER
        }
        val info = TextView(this).apply {
            text = "Painel flutuante demonstrativo. Não se conecta nem altera o Free Fire."
            textSize = 14f
            setTextColor(0xFFE8ECF3.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 18, 0, 24)
        }
        val launch = Button(this).apply {
            text = "ATIVAR JANELA FLUTUANTE"
            setOnClickListener { enableOverlay() }
        }
        layout.addView(title)
        layout.addView(info)
        layout.addView(launch)
        setContentView(layout)
    }

    private fun enableOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivity(intent)
            return
        }
        startService(Intent(this, OverlayService::class.java))
        finish()
    }

    override fun onResume() {
        super.onResume()
    }
}
