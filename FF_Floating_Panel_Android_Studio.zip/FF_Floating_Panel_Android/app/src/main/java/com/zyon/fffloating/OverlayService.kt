package com.zyon.fffloating

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class OverlayService : Service() {
    private lateinit var windowManager: WindowManager
    private var panel: View? = null
    private var minimized = false

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (panel == null) showPanel()
        return START_NOT_STICKY
    }

    private fun showPanel() {
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(14, 12, 14, 12)
            setBackgroundColor(0xF0141923.toInt())
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val title = TextView(this).apply {
            text = "FF PANEL"
            textSize = 16f
            setTextColor(0xFFFF4652.toInt())
            setPadding(4, 4, 18, 4)
        }
        val minimize = Button(this).apply {
            text = "—"
            setOnClickListener { toggleBody() }
        }
        val close = Button(this).apply {
            text = "×"
            setOnClickListener { stopSelf() }
        }
        header.addView(title, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(minimize)
        header.addView(close)
        root.addView(header)

        val body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            tag = "panel_body"
        }
        addToggle(body, "ESP • indicador demonstrativo")
        addToggle(body, "Nomes fictícios")
        addToggle(body, "Mira • indicador demonstrativo")
        addToggle(body, "Círculo de referência")
        val hint = TextView(this).apply {
            text = "DEMO — sem leitura ou alteração do jogo"
            textSize = 10f
            setTextColor(0xFF9AA5B5.toInt())
            setPadding(4, 10, 4, 2)
        }
        body.addView(hint)
        root.addView(body)

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 24
            y = 160
        }

        header.setOnTouchListener(object : View.OnTouchListener {
            private var startX = 0
            private var startY = 0
            private var touchX = 0f
            private var touchY = 0f
            override fun onTouch(v: View, event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        startX = params.x
                        startY = params.y
                        touchX = event.rawX
                        touchY = event.rawY
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        params.x = startX + (event.rawX - touchX).toInt()
                        params.y = startY + (event.rawY - touchY).toInt()
                        windowManager.updateViewLayout(root, params)
                        return true
                    }
                }
                return false
            }
        })

        panel = root
        windowManager.addView(root, params)
    }

    private fun addToggle(parent: LinearLayout, label: String) {
        val button = Button(this).apply {
            text = "○  $label"
            textSize = 11f
            setOnClickListener {
                val enabled = tag != true
                tag = enabled
                text = (if (enabled) "●  " else "○  ") + label
            }
        }
        parent.addView(button)
    }

    private fun toggleBody() {
        val root = panel as? LinearLayout ?: return
        val body = root.findViewWithTag<LinearLayout>("panel_body") ?: return
        minimized = !minimized
        body.visibility = if (minimized) View.GONE else View.VISIBLE
    }

    override fun onDestroy() {
        panel?.let { if (::windowManager.isInitialized) windowManager.removeView(it) }
        panel = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
