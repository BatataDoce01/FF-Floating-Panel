FF FLOATING PANEL — PROJETO ANDROID

Projeto Android Studio em Kotlin. Implementa uma janela flutuante Android:
- pode ser arrastada pela barra superior;
- pode ser minimizada/expandida;
- pode ser fechada;
- possui controles visuais demonstrativos.

Não é um cheat funcional: não injeta código, não lê memória, não detecta adversários,
não altera mira e não modifica o Free Fire.

COMO GERAR O APK
1. Instale Android Studio em um computador.
2. Abra a pasta FFFloatingPanel no Android Studio.
3. Aguarde a sincronização do Gradle.
4. Selecione Build > Build Bundle(s) / APK(s) > Build APK(s).
5. O APK de debug ficará em app/build/outputs/apk/debug/.

NO ANDROID
Na primeira ativação, permita "Exibir sobre outros apps" para FF Floating Panel.
Depois volte ao app e toque em ATIVAR JANELA FLUTUANTE.
